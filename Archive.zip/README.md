# Dreams Never End
This is an ASCII-based roguelike I made summer 2022, built from a JS/HTML/CSS roguelike framework developed from the ground up. Features include:
- Procedurally generated maps and items
- Combat system w/ different tiers of equipment (think Minecraft)
- Scaling difficulty
- Equipment upgrading

